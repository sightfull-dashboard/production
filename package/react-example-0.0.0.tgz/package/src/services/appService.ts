import { apiDelete, apiGet, apiPatch, apiPost, apiPut } from "../lib/api";
import type { Employee, LeaveRequest, PayrollSubmission, RosterAssignment, RosterMeta, Shift, SupportTicket, User } from "../types";

export const appService = {
  getEmployees: () => apiGet<Employee[]>("/api/employees"),
  saveEmployee: (employee: Partial<Employee>, id?: string) => id ? apiPut(`/api/employees/${id}`, employee) : apiPost('/api/employees', employee),
  deleteEmployee: (id: string) => apiDelete(`/api/employees/${id}`),

  getShifts: () => apiGet<Shift[]>("/api/shifts"),
  saveShift: (shift: Partial<Shift>, id?: string) => id ? apiPut(`/api/shifts/${id}`, shift) : apiPost('/api/shifts', shift),
  deleteShift: (id: string) => apiDelete(`/api/shifts/${id}`),

  getRoster: (weekStart?: string, periodDays?: number) => apiGet<RosterAssignment[]>(weekStart ? `/api/roster?week_start=${encodeURIComponent(weekStart)}${periodDays ? `&period_days=${encodeURIComponent(String(periodDays))}` : ''}` : '/api/roster'),
  getRosterMeta: (weekStart?: string) => apiGet<RosterMeta[]>(weekStart ? `/api/roster-meta?week_start=${encodeURIComponent(weekStart)}` : '/api/roster-meta'),

  getLeaveRequests: (employeeId?: string) => apiGet<LeaveRequest[]>(employeeId ? `/api/leave-requests?employee_id=${encodeURIComponent(employeeId)}` : '/api/leave-requests'),
  createLeaveRequest: (payload: Record<string, unknown>) => apiPost('/api/leave-requests', payload),
  updateLeaveStatus: (id: string, status: string, overrides: Record<string, unknown> = {}) => apiPut(`/api/leave-requests/${id}/status`, { status, ...overrides }),
  cancelLeaveRequest: (id: string) => apiPost(`/api/leave-requests/${id}/cancel`),

  getPayrollSubmissions: () => apiGet<PayrollSubmission[]>('/api/payroll-submissions'),
  createPayrollSubmission: (payload: Record<string, unknown>) => apiPost<PayrollSubmission>('/api/payroll-submissions', payload),
  updatePayrollSubmissionStatus: (id: string, status: string) => apiPut<PayrollSubmission>(`/api/payroll-submissions/${id}/status`, { status }),

  getSupportTickets: () => apiGet<SupportTicket[]>('/api/support-tickets'),
  createSupportTicket: (payload: Record<string, unknown>) => apiPost('/api/support-tickets', payload),
  updateSupportTicket: (id: string, payload: Record<string, unknown>) => apiPatch<SupportTicket>(`/api/support-tickets/${id}`, payload),

  getAuthUser: () => apiGet<User>('/api/auth/me'),
  login: (email: string, password: string) => apiPost<User>('/api/auth/login', { email, password }),
  logout: () => apiPost('/api/auth/logout'),

  getEmployeeSession: () => apiGet<Employee>('/api/employee-auth/me'),
  loginEmployee: (identifier: string, pin: string) => apiPost<Employee>('/api/employee-auth/login', { identifier, pin }),
  logoutEmployee: () => apiPost('/api/employee-auth/logout'),
};
